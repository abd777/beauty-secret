let shoreToken = '';
var axios = require("axios");
let expiresIn = null;
let validFrom = null;
module.exports = {
  async getShoreKey() {
    await axios
      .post("https://api.shore.com/v2/tokens", {
        grant_type: 'password',
        username: 'dropbox@beautysecret.ch',
        password: 'dropbox2022',
      })
      .then((token) => {
        shoreToken = token.data.access_token;
        expiresIn = token.data.expires_in;
        validFrom = new Date();
      });
      return shoreToken;
  },
};

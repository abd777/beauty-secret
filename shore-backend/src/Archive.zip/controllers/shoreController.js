const shoreAuthService = require("../services/shoreAuthService");
const shoreService = require("../services/shoreService");
var axios = require("axios");

const shoreKey = '';

const shoreInstance = axios.create({
  baseURL: "https://api.shore.co/v2",
  headers: {
    Authorization: `Bearer ${shoreKey}`,
    Accept: "application/vnd.api+json",
  },
});

module.exports = {

async createCustomer(req, res) {
	shoreKey = await shoreAuthService.getShoreKey();
   res.json(await shoreInstance.post('/customers', data));
  },
};






const data = {
	"data" : {
		"type" : "customers",
		"attributes" : {
            "opt_in": true,
            "opt_in_origin": "app-shell",
			"vip" : false,

		"given_name" : "Sayor",
		"surname" : "Doe",
		"addresses" : [
			{
				"name" : "work",
				"line1" : "Rosenheimer Str. 1",
				"line2" : "",
				"city" : "München",
				"state" : "Bayern",
				"country" : "DE",
				"postal_code" : "12345"
			}
		],
		"phones" : [
			{
				"name" : "Home",
				"value" : "+49 9999 9999999"
			}
		],
		"emails" : [
			{
				"name" : "Work",
				"value" : "john.doe@keln.com"
			}
		]
	},
	"relationships" : {
		"merchant" : {
			"data" : {
				"type" : "merchants",
				"id" : "fe454657-25bb-4fa9-91fb-abf004ac973f"
			}
		}
	}
}
};


